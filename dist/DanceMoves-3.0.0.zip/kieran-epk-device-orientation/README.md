# DanceMoves 3.0.0 for WordPress

[WordPress setup and all six Page metadata fields](docs/wordpress-shared-runtime.md)

This archive imports the shared DanceMoves JavaScript library.
Source, JavaScript/React/Next.js packages and release artifacts: https://github.com/kieransimkin/DanceMoves
